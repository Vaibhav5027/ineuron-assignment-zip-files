package in.ineuron;

public class College extends University  {

	public College() {
//      calling parent constructor using super method
		super();
		
		System.out.println("College constructor");
		
	}
}
