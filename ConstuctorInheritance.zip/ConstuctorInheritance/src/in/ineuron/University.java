package in.ineuron;
public class University {

  public University() {
	  
	 System.out.println("University Constructor");
}
}
