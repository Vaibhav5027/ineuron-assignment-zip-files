package in.ineuron;

public class ConstuctorCalling {


	public static void main(String[] args) {
		
		College college=new College();
	}

}
/**
 * 1. constructor are same has method which has same name as class name.
 * 2. to initialize the object we use constructor.
 * 3. there are two type of constructor zero-parameter and with parameter
 * 4. to invoke the parent class constructor we use "super() "method.
 * 
 * 
 * rules:
 * 1.name should be same as class name
 * 2.its not return anything
 * 3.constructor should not be static,final abstract.
 * 
 */
