package in.ineuron.service;

public interface IPolicyService {
 double getPolicyPrice (String company);
}
