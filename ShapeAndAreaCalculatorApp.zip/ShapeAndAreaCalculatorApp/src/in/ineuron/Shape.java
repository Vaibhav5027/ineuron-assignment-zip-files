package in.ineuron;

public interface Shape {
public double calculateArea();
public double calculatePerimeter();

}
