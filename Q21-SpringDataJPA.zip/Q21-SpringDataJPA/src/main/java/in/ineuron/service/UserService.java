package in.ineuron.service;

import in.ineuron.model.User;

public interface UserService {
	public User save(User user);
}
