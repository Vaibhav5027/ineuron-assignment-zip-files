package in.ineuron.service;

public interface UserServices {
	public void select();

	public void insert();

	public void update(Integer sid);

	public void delete(Integer sid);
}
